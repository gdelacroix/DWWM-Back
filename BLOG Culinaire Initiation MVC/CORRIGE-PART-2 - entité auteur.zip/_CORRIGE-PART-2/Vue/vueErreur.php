<?php $this->titre = 'Le Blog Culinaire - Erreur'; ?>

<p>Une erreur est survenue : <?= $msgErreur ?></p>
