<?php

require_once 'Controleur/Routeur.php';
$routeur = new Routeur();
$routeur->routerRequete();


