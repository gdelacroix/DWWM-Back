<?php 
@$numDossier = $_POST["numDossier"];

?>